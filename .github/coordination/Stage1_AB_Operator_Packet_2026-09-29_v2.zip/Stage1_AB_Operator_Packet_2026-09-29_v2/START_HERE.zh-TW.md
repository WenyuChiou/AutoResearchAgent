# Stage 1 正式 A/B 執行包（v2，PR #61 合併後）

這份資料包供組員在新的 **GPT-6 Astra、High、Goal Mode** 協調任務中使用。Astra 只負責操作、驗證、保存證據與產生報告；正式受測條件仍固定使用 **GPT-5.6 Sol、High、Task/Default mode**。

比較條件固定為：

- **A：Codex harness，不載入 AutoResearchAgent research harness。**
- **B：相同 Codex harness 與原生搜尋／閱讀能力，再加上凍結的 AutoResearchAgent Stage 1 harness。**

組員只需要取得：

1. 本 ZIP。
2. 核心組另外提供的 `Stage1_US_AB_Reanalysis_v33.zip` 本機路徑。它不包含在本 ZIP，也不得上傳 GitHub。
3. 核心組凍結的 fork `main` SHA；記錄於 `CURRENT_STATE.json`。這版已更新至 PR #61 merge SHA，請勿使用舊版 ZIP 的 pin。

操作方式：

1. 建立新的 Goal Mode 任務。
2. 附上或解壓本 ZIP。
3. 將私有 v33 ZIP 放在 Git 以外的私有目錄。
4. 貼上 `TEAMMATE_CODEX_PROMPT_EN.txt` 全文。
5. 只在 prompt 要求時告訴協調代理 v33 ZIP 的完整路徑。
6. 代理先完成 G1 與未計分 Japan pilot，再產生 `FREEZE_READY` manifest。
7. 將 manifest 與 SHA-256 回傳給 Eric。只有 Eric 回覆完全相同 digest 的 `FREEZE_APPROVED` 後，才執行正式六次 A/B。

不得把舊的 South Korea prompt、Canada pilot 或早期 Japan diagnostic 當正式結果。不得因時間壓力更換模型、prompt、rubric、pair order 或只重跑表現較差的一側。

