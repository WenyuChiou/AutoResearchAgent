# 回傳檢查表

## 啟動與 G1

- [ ] fork main、plugin、research-hub、subject/evaluator runtime hashes 完整
- [ ] 私有 v33 ZIP bytes 與 SHA-256 完全吻合
- [ ] G1 6/6 complete，verified replay 0 new subject calls
- [ ] 原 captures／answers bytes 未變
- [ ] evaluator omission 不會變成 subject failure

## 未計分 Japan pilot

- [ ] A 與 B 原生能力相同，只有 B 多 research harness
- [ ] current merged-main 一對完整 captures
- [ ] R1／R2 與必要 ADJ 完整
- [ ] 完整 B 文獻交付包與合法公開來源
- [ ] exporter replay、tamper、repository guardrail 通過
- [ ] Stage 1→Stage 2 v2 import/validation 通過且零候選
- [ ] pilot report 不把 replay complete 寫成 comparison accepted

## Freeze gate

- [ ] `FREEZE_READY` manifest 綁定所有版本與政策
- [ ] dry validators 通過
- [ ] Eric 核對並回覆完全相同 SHA-256 的 `FREEZE_APPROVED`

## 正式 A/B

- [ ] A→B、B→A、A→B 六次 runs，沒有選擇性重跑
- [ ] 六份 evaluator archives
- [ ] R1／R2 獨立；只在分歧時使用 ADJ
- [ ] 必要 human audits 真實完成，否則為 inconclusive
- [ ] 十個 criteria 與 P1／P2／P3 分開報告，沒有合成總分
- [ ] P2/P3 至少兩對改善且零退步；P1 零退步；B 無新增 major error，或如實記錄未通過
- [ ] CSV、JSON、HTML、paired decision、成本與失敗紀錄完整
- [ ] 私有內容與論文全文未提交 GitHub
- [ ] private ZIP 與 public-safe summary 均可驗證

